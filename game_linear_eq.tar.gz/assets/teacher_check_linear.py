# ==========================================
# teacher_check_linear.py  -  TEACHER ONLY (never share with students)
# Checks completion codes from the Math 9 Linear Relations Pokemon game (main.py).
#
# How to use (Windows):
#   Double-click this file, or run:   python teacher_check_linear.py
#   Type the student's name (optional), then paste or type their code.
#   You can also check codes directly:  python teacher_check_linear.py L1-ABCD-EFGH-JKMN
#
# For each code it shows: VALID or FAKE, the topic, when it was finished,
# and how many questions were right / wrong.
#
# Every checked code is saved to linear_codes_log.csv (open it in Excel).
# If the same code is checked twice, it warns you: each win makes a unique code,
# so two students with the same code means one copied it.
#
# The secret key below MUST match the one in main.py.
# ==========================================

import hashlib
import hmac
import csv
import os
import sys
from datetime import datetime

_K = bytes(b ^ 0x5A for b in [
    130, 177, 43, 187, 165, 27, 147, 6, 75, 194, 254, 81, 81, 114, 212, 189,
    94, 13, 20, 151, 164, 34, 144, 179, 231, 190, 38, 31, 195, 46, 185, 170])
_ALPHA = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
_UNIT = "MATH9-W8-LINEAR-RELATIONS"
_EPOCH = 1788220800        # 2026-09-01 00:00 UTC

TOPICS = {
    1: "Topic 1: Points & Patterns",
    2: "Topic 2: Representing Relations",
    3: "Topic 3: Table to Equation",
    4: "Topic 4: Graphing Lines",
    5: "Topic 5: Reading Graphs",
    6: "Topic 6: Comparing Relations",
}

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linear_codes_log.csv")


def check_code(code):
    """Returns (ok, info). info is a dict when ok, otherwise a reason (text)."""
    raw = code.strip().upper().replace(" ", "")
    parts = raw.split("-")
    if len(parts) == 4:
        prefix, body = parts[0], "".join(parts[1:])
    elif len(parts) == 1 and len(raw) >= 14:          # typed without dashes
        prefix, body = raw[:-12], raw[-12:]
    else:
        return False, "Wrong format. It should look like L1-ABCD-EFGH-JKMN."
    if not (prefix.startswith("L") and prefix[1:].isdigit()):
        return False, "Code must start with L and the topic number (like L1)."
    if len(body) != 12:
        return False, "The code needs 12 letters/numbers after the L-number."
    bad = [ch for ch in body if ch not in _ALPHA]
    if bad:
        hint = ""
        if any(ch in "01OIL" for ch in bad):
            hint = "  (Codes never use 0, 1, O, I or L after the dash -- check for a typo.)"
        return False, f"Contains characters that can't be in a code: {''.join(sorted(set(bad)))}.{hint}"

    n = 0
    for ch in reversed(body):
        n = n * len(_ALPHA) + _ALPHA.index(ch)
    payload, sig = n >> 24, n & 0xFFFFFF
    if payload >> 35:
        return False, "FAKE: not a real code."
    expected = hmac.new(_K, _UNIT.encode() + payload.to_bytes(5, "big"), hashlib.sha256).digest()[:3]
    if int.from_bytes(expected, "big") != sig:
        return False, "FAKE: this code was not made by the game (or it has a typo)."

    level = (payload >> 32) + 1
    minutes = (payload >> 12) & 0xFFFFF
    correct = (payload >> 6) & 63
    wrong = payload & 63
    if int(prefix[1:]) != level:
        return False, "FAKE: the L-number was changed (it doesn't match the topic inside the code)."
    if level not in TOPICS:
        return False, "FAKE: unknown topic."

    finished = datetime.fromtimestamp(_EPOCH + minutes * 60)   # your computer's local time
    total = correct + wrong
    return True, {
        "code": f"L{level}-{body[:4]}-{body[4:8]}-{body[8:]}",
        "level": level,
        "topic": TOPICS[level],
        "finished": finished,
        "correct": correct,
        "wrong": wrong,
        "accuracy": round(100 * correct / total) if total else 0,
        "capped": correct >= 63 or wrong >= 63,
    }


def load_log():
    seen = {}
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                seen.setdefault(row["code"], []).append(row)
    return seen


def add_to_log(student, info, status):
    new = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["checked_on", "student", "code", "status", "topic",
                        "finished", "correct", "wrong", "accuracy_%"])
        w.writerow([datetime.now().strftime("%Y-%m-%d %H:%M"), student, info["code"], status,
                    info["topic"], info["finished"].strftime("%Y-%m-%d %H:%M"),
                    info["correct"], info["wrong"], info["accuracy"]])


def report(code, student="", log=True):
    ok, info = check_code(code)
    print()
    if not ok:
        print("  XX  NOT VALID:", info)
        return
    seen = load_log()
    earlier = seen.get(info["code"], [])
    status = "VALID" if not earlier else "DUPLICATE"

    print(f"  OK  VALID code for {info['topic']}")
    print(f"      Finished: {info['finished'].strftime('%a %b %d, %Y at %I:%M %p')}")
    more = "+" if info["capped"] else ""
    print(f"      Correct: {info['correct']}{more}   Wrong: {info['wrong']}{more}   "
          f"Accuracy: {info['accuracy']}%")
    if earlier:
        who = ", ".join(sorted({r["student"] or "(no name)" for r in earlier}))
        print(f"  !!  WARNING: this exact code was already checked for: {who}")
        print("      Each win makes its own code, so a repeat usually means it was copied.")
    if log:
        add_to_log(student, info, status)


def main():
    if len(sys.argv) > 1:
        for code in sys.argv[1:]:
            report(code)
        return
    print("Linear Relations Pokemon Battle - completion code checker (teacher only)")
    print("Press Enter on an empty code to quit.")
    while True:
        print()
        student = input("Student name (optional): ").strip()
        code = input("Completion code: ").strip()
        if not code:
            break
        report(code, student)
    print(f"\nAll checks are saved in: {LOG_FILE}")


if __name__ == "__main__":
    main()
