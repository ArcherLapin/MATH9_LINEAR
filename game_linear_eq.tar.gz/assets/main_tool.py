# ==========================================
# main_tool.py  -  shared engine for Mr. Chung's Pokemon Math Battle games
#   Scaling, fonts, text, animations, Pokemon, moves, buttons, messages,
#   music, and the show/hide visual panel (tables, grids, context graphs).
#   No game content lives here; each game's main.py supplies its questions.
# ==========================================
import pygame
import random
import os
import sys


# ==========================================
# 1. PATHS & SCALING
# ==========================================
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)


BASE_W, BASE_H = 1080, 950
curr_w, curr_h = 1080, 950


def rx(x): return int((x / BASE_W) * curr_w)
def ry(y): return int((y / BASE_H) * curr_h)
def rs(size): return max(2, int(size * min(curr_w / BASE_W, curr_h / BASE_H)))


# ==========================================
# 2. FONTS & TEXT
# ==========================================
FONT_PATH = "caslon.ttf"
_font_cache = {}


def get_font(size):
    scaled = rs(size)
    if scaled not in _font_cache:
        _font_cache[scaled] = pygame.font.Font(resource_path(FONT_PATH), scaled)
    return _font_cache[scaled]


def draw_text(surface, text, color, base_x, base_y, base_size=26):
    surface.blit(get_font(base_size).render(text, True, color), (rx(base_x), ry(base_y)))


def draw_centered(surface, text, size, color, base_y, base_x=BASE_W / 2):
    surf = get_font(size).render(text, True, color)
    surface.blit(surf, surf.get_rect(center=(rx(base_x), ry(base_y))))


def fit_size(text, base_size, max_w, min_size=12):
    """Largest font size (<= base_size) that keeps text within max_w base pixels."""
    size = base_size
    while size > min_size and get_font(size).size(text)[0] > rx(max_w):
        size -= 1
    return size


def draw_fit(surface, text, color, base_x, base_y, base_size=26, max_w=920):
    """Like draw_text, but shrinks long text so it stays on one line."""
    size = fit_size(text, base_size, max_w)
    surface.blit(get_font(size).render(text, True, color), (rx(base_x), ry(base_y)))


# ==========================================
# 3. ANIMATION FRAMES
# ==========================================
def load_frames(path_template, target_size=None, scale_factor=1.0, max_frames=60):
    """Load 'name (1).gif', 'name (2).gif', ... until a file is missing."""
    frames = []
    for i in range(1, max_frames + 1):
        try:
            img = pygame.image.load(path_template.format(i=i))
        except (pygame.error, FileNotFoundError, OSError):
            break
        if target_size:
            img = pygame.transform.scale(img, target_size)
        elif scale_factor != 1.0:
            img = pygame.transform.scale(img, (int(img.get_width() * scale_factor),
                                               int(img.get_height() * scale_factor)))
        frames.append(img)
    return frames


class Animation:
    def __init__(self, original_frames, speed=4, loop=False):
        self.original_frames = original_frames
        self.frames = original_frames
        self.speed = speed
        self.loop = loop
        self.timer = 0
        self.is_playing = loop
        self.last_size = (BASE_W, BASE_H)

    def play(self):
        self.timer = 0
        self.is_playing = True

    def draw(self, surface, base_x, base_y):
        if not self.is_playing or not self.original_frames:
            return
        if self.last_size != (curr_w, curr_h):          # only rescale if the window changed
            self.frames = [pygame.transform.scale(img, (rx(img.get_width()), ry(img.get_height())))
                           for img in self.original_frames]
            self.last_size = (curr_w, curr_h)

        frame_idx = self.timer // self.speed
        if frame_idx >= len(self.frames):
            if not self.loop:
                self.is_playing = False
                return
            self.timer, frame_idx = 0, 0
        surface.blit(self.frames[frame_idx], (rx(base_x), ry(base_y)))
        self.timer += 1


def load_vfx():
    """All attack/heal effect frames, loaded once."""
    spec = {
        "hit":         ("hit",           (400, 400)),
        "heal":        ("heal",          (400, 400)),
        "firepunch":   ("firepunch",     (500, 500)),
        "thunderbolt": ("lightning",     (200, 500)),
        "hydropump":   ("water",         (600, 600)),
        "thunder":     ("green_thunder", (500, 600)),
        "leaftornado": ("leaf_tornado",  (400, 600)),
    }
    return {key: load_frames(resource_path(f"vfx/{fname} ({{i}}).gif"), target_size=size)
            for key, (fname, size) in spec.items()}


# ==========================================
# 4. POKEMON
# ==========================================
# Screen layout per sprite folder (pokemon0 = player, pokemon1.. = opponents).
#   faction: (ui_x, ui_y, img_x, img_y, thunderbolt_dx, thunderbolt_dy, sprite_scale)
# To add a new opponent: make a folder pokemonN with 'pokemon_N (1).gif'...
# and 'pokemonN_faint.ogg', then add a row here (or it uses DEFAULT_LAYOUT).
FACTION_LAYOUT = {
    0: (575, 485,  50,  350, 70,    0, 0.75),
    1: (150, 100, 650,  150, 70, -350, 1.1),
    2: (150, 100, 650,  160, 50, -350, 1.0),
    3: (150, 100, 600,  165, 50, -350, 1.0),
    4: (150, 100, 600,  140, 50, -350, 1.1),
    5: (150, 100, 600,  140, 50, -350, 1.1),
    6: (150, 100, 650,  140, 50, -350, 1.1),
}
DEFAULT_LAYOUT = (150, 100, 600, 150, 50, -350, 1.0)

_idle_cache = {}     # faction -> idle frames (so replaying a battle doesn't reload gifs)


class Pokemon:
    ANIM_SPEED = {"hit": 3, "heal": 3, "thunderbolt": 3, "firepunch": 4,
                  "hydropump": 4, "thunder": 3, "leaftornado": 3}

    def __init__(self, faction, name, hp, max_hp, attack, defense, vfx_frames):
        self.faction, self.name = faction, name
        self.hp, self.max_hp = hp, max_hp
        self.attack, self.defense = attack, defense
        self.moves = []

        (self.ui_x, self.ui_y, self.img_x, self.img_y,
         self.tb_offset_x, self.tb_offset_y, scale) = FACTION_LAYOUT.get(faction, DEFAULT_LAYOUT)

        if faction not in _idle_cache:
            _idle_cache[faction] = load_frames(
                resource_path(f"pokemon{faction}/pokemon_{faction} ({{i}}).gif"), scale_factor=scale)
        self.animations = {"idle": Animation(_idle_cache[faction], speed=4, loop=True)}
        for key, speed in self.ANIM_SPEED.items():
            self.animations[key] = Animation(vfx_frames.get(key, []), speed=speed)

        try:
            self.faint_sound = pygame.mixer.Sound(resource_path(f"pokemon{faction}/pokemon{faction}_faint.ogg"))
            self.faint_sound.set_volume(0.4)
        except (pygame.error, FileNotFoundError, OSError):
            self.faint_sound = None

    def play_faint_sound(self):
        if self.faint_sound:
            self.faint_sound.play()

    def trigger_vfx(self, effect_data):
        effects = effect_data if isinstance(effect_data, (list, tuple)) else [effect_data]
        for effect in effects:
            if effect in self.animations:
                self.animations[effect].play()

    def draw(self, surface):
        draw_text(surface, self.name, (255, 255, 255), self.ui_x, self.ui_y)
        ratio = max(0, self.hp / self.max_hp)
        pygame.draw.rect(surface, (255, 0, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300), ry(12)))
        pygame.draw.rect(surface, (0, 255, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300 * ratio), ry(12)))
        draw_text(surface, f"HP: {int(self.hp)} / {int(self.max_hp)}", (255, 255, 255), self.ui_x, self.ui_y + 60)

        x, y, a = self.img_x, self.img_y, self.animations
        a["idle"].draw(surface, x, y)
        a["hit"].draw(surface, x, y + 25)
        a["heal"].draw(surface, x, y)
        a["firepunch"].draw(surface, x - 20, y - 150)
        a["thunderbolt"].draw(surface, x + self.tb_offset_x, y + self.tb_offset_y)
        a["hydropump"].draw(surface, x - 50, y - 50)
        a["thunder"].draw(surface, x - 50, y - 220)
        a["leaftornado"].draw(surface, x - 50, y - 220)


# ==========================================
# 5. MESSAGES, MOVES, BUTTONS
# ==========================================
class MessageSystem:
    def __init__(self):
        self.queue, self.current = [], ""

    def draw(self, surface):
        draw_fit(surface, self.current, (255, 255, 255), 80, 750, max_w=920)

    def add(self, text, target=None, hp_change=0, vfx=None, sound=None):
        self.queue.append({"text": text, "target": target, "hp_change": hp_change, "vfx": vfx, "sound": sound})

    def clear(self):
        self.current = ""

    def has_active_message(self):
        return bool(self.current) or bool(self.queue)

    def update(self):
        if self.current or not self.queue:
            return
        msg = self.queue.pop(0)
        self.current = msg["text"]
        t = msg["target"]
        if t is None:
            return
        t.hp += msg["hp_change"]
        if msg["hp_change"] < 0:
            if msg["vfx"]:   t.trigger_vfx(msg["vfx"])
            if msg["sound"]: msg["sound"].play()
        elif msg["hp_change"] > 0:
            t.trigger_vfx("heal")
        t.hp = max(0, min(t.hp, t.max_hp))


class Move:
    def __init__(self, name, power, miss_chance, crit_chance, category, vfx, sound):
        self.name, self.power = name, power
        self.miss_chance, self.crit_chance = miss_chance, crit_chance
        self.category, self.vfx, self.sound = category, vfx, sound

    def execute(self, attacker, defender, msg_sys, heal_sound_ref):
        msg_sys.add(f"{attacker.name} used {self.name}!")
        if self.category == "heal":
            msg_sys.add(f"{attacker.name} recovered HP!", target=attacker, hp_change=self.power)
            if heal_sound_ref: heal_sound_ref.play()
        elif self.category == "buff":
            attacker.attack *= self.power
            msg_sys.add(f"{attacker.name}'s Attack sharply rose!")
        else:
            damage = int(self.power * (attacker.attack / 100))
            if random.randint(1, 100) <= self.miss_chance:
                msg_sys.add(f"{attacker.name}'s Attack missed!")
            elif random.randint(1, 100) <= self.crit_chance:
                msg_sys.add(f"A critical hit! It dealt {int(damage * 1.5)} damage!",
                            target=defender, hp_change=-int(damage * 1.5), vfx=self.vfx, sound=self.sound)
            else:
                msg_sys.add(f"It dealt {damage} damage!", target=defender, hp_change=-damage,
                            vfx=self.vfx, sound=self.sound)


class Button:
    def __init__(self, base_x, base_y, base_w, base_h, color=(150, 200, 200), base_size=24):
        self.text = ""
        self.bx, self.by, self.bw, self.bh = base_x, base_y, base_w, base_h
        self.color, self.base_size = color, base_size

    def rect(self):
        return pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))

    def draw(self, surface):
        rect = self.rect()
        pygame.draw.rect(surface, self.color, rect)
        pygame.draw.rect(surface, (0, 0, 0), rect, max(1, rs(2)))
        # Same sizing as the original game: start at size 24 and shrink until the text
        # fits the button with a 5 px margin on each side.
        pad = 10
        size = fit_size(self.text, self.base_size, self.bw - pad, min_size=8)
        words = self.text.split()
        if size < 17 and len(words) > 2:                  # very long choice: wrap onto two lines
            best = None
            for k in range(1, len(words)):
                a, b = " ".join(words[:k]), " ".join(words[k:])
                sz = min(fit_size(a, 22, self.bw - pad, 8), fit_size(b, 22, self.bw - pad, 8))
                if best is None or sz > best[0]:
                    best = (sz, a, b)
            if best[0] > size:
                sz, a, b = best
                for line, dy in ((a, -0.27), (b, 0.27)):
                    t = get_font(sz).render(line, True, (0, 0, 0))
                    surface.blit(t, t.get_rect(center=(rect.centerx, rect.centery + int(dy * rect.h))))
                return
        text_surface = get_font(size).render(self.text, True, (0, 0, 0))
        surface.blit(text_surface, text_surface.get_rect(center=rect.center))

    def clicked(self, mousepos):
        return self.rect().collidepoint(mousepos)


# ==========================================
# 6. MUSIC
# ==========================================
MUSIC_END_EVENT = pygame.USEREVENT + 1


def play_random_track(music_pool):
    if not music_pool:
        return
    try:
        pygame.mixer.music.load(resource_path(f"music{random.choice(music_pool)}.ogg"))
        pygame.mixer.music.set_volume(0.15)
        pygame.mixer.music.play(0)
    except pygame.error:
        pass


# ==========================================
# 7. VISUAL PANEL  (show/hide: tables, coordinate grids, context graphs)
# ==========================================
# A "visual" is a dict.  Any of these keys may be present (drawn top to bottom):
#   "notes":  ["line of text", ...]                  extra info / situation text
#   "table":  {"rows": [("x", [1, 2, 3]), ("y", [4, "?", 10])], "vertical": False}
#   "grid":   {"r": 8, "lines": [(m, b[, "A"]) | ("h", b[, "A"]) | ("v", a[, "A"])],
#              "points": [(x, y, "label"), ...]}     standard -r..r coordinate grid
#   "graph":  {"title", "xlabel", "ylabel", "xmax", "xstep", "ymax", "ystep",
#              "line": (m, b) or None, "pts": [(x, y), ...],          dots on the line
#              "labels": [(x, y, "text"), ...],                       labelled points on the line
#              "scatter": [(x, y), ...],                              data (line of best fit)
#              "highlight": [(x, y, "text"), ...]}                    a green data point
PANEL = pygame.Rect(40, 15, 1000, 695)      # base coords; battle area is y < 720
INK, GRID_C, AXIS_C, LINE_C = (20, 20, 20), (200, 205, 215), (40, 40, 40), (25, 95, 190)


def _P(x, y):
    return (rx(x), ry(y))


def _txt(surface, text, size, center, color=INK):
    s = get_font(size).render(str(text), True, color)
    surface.blit(s, s.get_rect(center=center))


def _table_size(table, max_w=900):
    rows = table["rows"]
    n = max(len(vals) for _, vals in rows)
    head_w = max(70, max(get_font(26).size(str(h))[0] for h, _ in rows) + 30)
    cell_w = min(110, (max_w - head_w) // n)
    return n, head_w, cell_w, head_w + n * cell_w


def draw_table(surface, table, cx, top, max_w=900):
    rows = table["rows"]
    n, head_w, cell_w, total_w = _table_size(table, max_w)
    cell_h = 56
    left = cx - total_w // 2
    for r, (head, vals) in enumerate(rows):
        y = top + r * cell_h
        hdr = pygame.Rect(*_P(left, y), rx(head_w), ry(cell_h))
        pygame.draw.rect(surface, (225, 232, 240), hdr)
        pygame.draw.rect(surface, INK, hdr, max(1, rs(2)))
        _txt(surface, head, 26, hdr.center)
        for c in range(n):
            cell = pygame.Rect(*_P(left + head_w + c * cell_w, y), rx(cell_w), ry(cell_h))
            pygame.draw.rect(surface, INK, cell, max(1, rs(2)))
            v = vals[c] if c < len(vals) else ""
            _txt(surface, v, 28, cell.center, (200, 30, 30) if v == "?" else INK)
    return top + len(rows) * cell_h


def _line_ends(m, b, lo, hi):
    """Clip y = mx + b to the box [lo, hi] x [lo, hi]."""
    pts = []
    for x in (lo, hi):
        y = m * x + b
        if lo <= y <= hi:
            pts.append((x, y))
    if m != 0:
        for y in (lo, hi):
            x = (y - b) / m
            if lo <= x <= hi:
                pts.append((x, y))
    pts = sorted(set(pts))
    return (pts[0], pts[-1]) if len(pts) >= 2 else None


def draw_grid(surface, grid, cx, top, size_px):
    r = grid.get("r", 8)
    unit = size_px / (2 * r)
    left = cx - size_px / 2

    def to_px(x, y):
        return _P(left + (x + r) * unit, top + (r - y) * unit)

    for k in range(-r, r + 1):
        w = max(1, rs(3)) if k == 0 else 1
        col = AXIS_C if k == 0 else GRID_C
        pygame.draw.line(surface, col, to_px(k, -r), to_px(k, r), w)
        pygame.draw.line(surface, col, to_px(-r, k), to_px(r, k), w)
        if k != 0 and k % 2 == 0:
            px, py = to_px(k, 0)
            _txt(surface, k, 16, (px, py + rs(12)))
            px, py = to_px(0, k)
            _txt(surface, k, 16, (px - rs(14), py))
    px, py = to_px(r, 0)
    _txt(surface, "x", 22, (px + rs(14), py))
    px, py = to_px(0, r)
    _txt(surface, "y", 22, (px + rs(16), py - rs(4)))

    colors = [LINE_C, (200, 60, 40), (30, 140, 70), (150, 70, 190)]
    for i, ln in enumerate(grid.get("lines", [])):
        col = colors[i % len(colors)] if len(grid["lines"]) > 1 else LINE_C
        if ln[0] == "h":
            ends = ((-r, ln[1]), (r, ln[1]))
        elif ln[0] == "v":
            ends = ((ln[1], -r), (ln[1], r))
        else:
            ends = _line_ends(ln[0], ln[1], -r, r)
        if not ends:
            continue
        pygame.draw.line(surface, col, to_px(*ends[0]), to_px(*ends[1]), max(2, rs(4)))
        if len(ln) > 2:                                    # line name near its upper end
            a, b = ends if ends[1][1] >= ends[0][1] else (ends[1], ends[0])
            f = (0.9, 0.72, 0.54, 0.36)[i % 4]               # stagger names so they don't overlap
            px, py = to_px(a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1]))
            pygame.draw.circle(surface, (255, 255, 255), (px + rs(18), py), rs(16))
            _txt(surface, ln[2], 26, (px + rs(18), py), col)
    for x, y, label in grid.get("points", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (210, 40, 40), p, max(3, rs(7)))
        if label:
            _txt(surface, label, 24, (p[0] + rs(16), p[1] - rs(16)), (170, 20, 20))


def draw_context_graph(surface, g, area):
    """First-quadrant graph with a title, labelled axes and scales (area = base Rect)."""
    ax_left, ax_bottom = area.x + 110, area.bottom - 70
    ax_w, ax_h = area.w - 150, area.h - 130
    xmax, ymax = g["xmax"], g["ymax"]

    def to_px(x, y):
        return _P(ax_left + x / xmax * ax_w, ax_bottom - y / ymax * ax_h)

    _txt(surface, g["title"], 28, _P(area.centerx, area.y + 20))
    for k in range(0, xmax + 1, g["xstep"]):
        pygame.draw.line(surface, GRID_C, to_px(k, 0), to_px(k, ymax), 1)
        px, py = to_px(k, 0)
        _txt(surface, k, 20, (px, py + rs(16)))
    for k in range(0, ymax + 1, g["ystep"]):
        pygame.draw.line(surface, GRID_C, to_px(0, k), to_px(xmax, k), 1)
        px, py = to_px(0, k)
        _txt(surface, k, 20, (px - rs(10) - get_font(20).size(str(k))[0] // 2, py))
    pygame.draw.line(surface, AXIS_C, to_px(0, 0), to_px(xmax, 0), max(1, rs(3)))
    pygame.draw.line(surface, AXIS_C, to_px(0, 0), to_px(0, ymax), max(1, rs(3)))
    _txt(surface, g["xlabel"], 22, _P(ax_left + ax_w / 2, ax_bottom + 50))
    lab = get_font(22).render(g["ylabel"], True, INK)
    lab = pygame.transform.rotate(lab, 90)
    surface.blit(lab, lab.get_rect(center=_P(area.x + 22, ax_bottom - ax_h / 2)))

    if g.get("line"):
        m, b = g["line"]
        x_end = xmax if m >= 0 else min(xmax, -b / m)
        x_end = min(x_end, (ymax - b) / m) if m > 0 else x_end
        pygame.draw.line(surface, LINE_C, to_px(0, b), to_px(x_end, m * x_end + b), max(2, rs(4)))
    for x, y in g.get("scatter", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (90, 70, 0), p, max(3, rs(7)))
        pygame.draw.circle(surface, (245, 200, 40), p, max(2, rs(5)))
    for x, y in g.get("pts", []):
        pygame.draw.circle(surface, LINE_C, to_px(x, y), max(3, rs(7)))
    for x, y, text in g.get("highlight", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (20, 150, 60), p, max(3, rs(9)))
        s = get_font(22).render(text, True, (10, 120, 40))
        surface.blit(s, s.get_rect(midleft=(p[0] + rs(14), p[1])))
    for x, y, text in g.get("labels", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (120, 60, 200), p, max(3, rs(8)))
        _txt(surface, text, 22, (p[0] + rs(10), p[1] - rs(22)), (110, 40, 190))


BATTLE_H = 720                                  # the battle area above the text box


def draw_visual_panel(surface, visual):
    left, top, w, h = PANEL.x, PANEL.y, PANEL.w, PANEL.h
    if "grid" not in visual and "graph" not in visual:
        # short info / table only: a pop-up sized to fit, exactly in the middle of the battle area
        notes = visual.get("notes", [])
        h = 35 + 44 * len(notes)
        widths = [get_font(fit_size(n, 28, PANEL.w - 60)).size(n)[0] for n in notes]
        if "table" in visual:
            h += 15 + 56 * len(visual["table"]["rows"]) + 15
            widths.append(_table_size(visual["table"])[3])
        w = min(PANEL.w, max([420] + [wd + 80 for wd in widths]))
        left, top = (BASE_W - w) // 2, (BATTLE_H - h) // 2
    box = pygame.Rect(*_P(left, top), rx(w), ry(h))
    pygame.draw.rect(surface, (250, 250, 245), box)
    pygame.draw.rect(surface, INK, box, max(1, rs(3)))
    y = top + 25
    for line in visual.get("notes", []):
        size = fit_size(line, 28, PANEL.w - 60)
        _txt(surface, line, size, _P(BASE_W // 2, y + 12))
        y += 44
    if "table" in visual:
        y = draw_table(surface, visual["table"], BASE_W // 2, y + 15) + 25
    if "grid" in visual:
        size = min(PANEL.bottom - y - 30, 640)
        draw_grid(surface, visual["grid"], PANEL.centerx, y + 10, size)
    if "graph" in visual:
        draw_context_graph(surface, visual["graph"],
                           pygame.Rect(PANEL.x + 60, y, PANEL.w - 120, PANEL.bottom - y - 10))
